# USB PHY UVM incremental update — work in progress

This is a partial upgrade of the supplied environment, not a complete verification solution. Existing DUT RTL, architecture, agents, sequences and file list are retained. No HDL simulator was available; the modified code has not been compiled or run. No test, verification block or coverage target has passed as a result of this delivery.

## Changes in this snapshot

- The existing TX wire checker samples resolved D+/D− through `usb_bus_if`, while still using the PHY interface for SIE handshake and TX ownership.
- The digital AFE abstraction derives `analog_serial` from the resolved bus. For LS and FS, J maps to 1 and K to 0; SE0 and SE1 use configurable `top_tb` parameters, initially 0. Contention or unknown bus levels produce X. These are digital modeling assumptions and need validation against the actual AFE. The HS mapping is only an abstraction; it does not implement HS RX.
- The existing scoreboard adds conservative status lines and scoped byte-check event counts. Missing independent block checks cannot become PASS. Its overall FAIL is a deliberate conservative interim result, not the result of an executed simulation. UVM report counts are a report-phase snapshot; regression totals, complete comparison totals, assertion totals, actual seed and merged coverage are not supplied by the report.
- `VERIFICATION_MATRIX.md` maps RTL hierarchy and actual port signals to planned independent checks, tests and coverage. The plan distinguishes existing RTL, proposed work and unsupported HS integration.

## Critical limitations and remaining work

The supplied `usb2_cdr_top` disables its CDR at HS and `phy_top` has no external HS receive bypass. The documented HS receive path needs an actual RTL/AFE integration and interface contract before top-level HS RX can work; the CDR v6 document expects a separate external HS PHY. The PHY RX module has HS-related digital logic, which must not be confused with a functioning top-level HS path.

Independent stage monitors and reference models, bus-decoded RX oracle, CDR timing checks, full protocol/packet validation, randomized/negative tests, functional coverage extensions, failure attribution and regression aggregation remain to be implemented. Existing byte checks and the old CDR test do not establish these capabilities. The PHY is a byte-oriented digital interface; packet-level CRC/PID checking belongs in an explicitly defined verification layer and must not be mistaken for DUT functionality.

The scoreboard is a fail-closed interim report, not a complete coverage-driven status engine. Its printed overall FAIL is informational and does not by itself force a nonzero simulator exit status. It cannot yet attribute TX wire-checker errors to every block, count all assertions or aggregate separate test runs. Detailed acceptance criteria are not met. Revalidate old testbench behavior after the AFE change. In particular, check SE0/SE1, back-to-back packets, reset, contention and speed polarity.

## Commands for an Xcelium environment

From `sim/`, run:

```sh
make compile
make run TEST=usb_phy_full_path_test USB_SPEED=1 SEED=123
make run TEST=usb_phy_cdr_test USB_SPEED=0 SEED=123
make run TEST=usb_phy_cdr_test USB_SPEED=1 SEED=123
make regression SEED=123
```

Logs are written under `sim/logs/`. `USB_SPEED=0`, `1`, and `2` select LS, FS and HS respectively. The existing regression is a baseline list, not the complete randomized and negative test matrix. A passing process exit or successful TX run does not imply the requested overall acceptance has passed. Investigate `UVM_ERROR`, `UVM_FATAL`, bus contention, X/Z, pending queues and the conservative `USB_VERIFY` report. The existing log may use scoreboard local error totals distinct from the global UVM error count.

Before relying on these modifications, compile and run the baseline against the original and modified bench with a licensed Xcelium, compare logs, and review the AFE treatment and timing with the design owner.
